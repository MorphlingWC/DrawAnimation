//
//  AppDelegate.h
//  DrawAnimation
//
//  Created by weichao on 10/10/16.
//  Copyright © 2016 weichao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

