//
//  PreView.m
//  PlaneGame
//
//  Created by weichao on 10/8/16.
//  Copyright © 2016 weichao. All rights reserved.
//

#import "PreView.h"
#define pi 3.1415926
#define DEGRESS_TO_RADIANS(degrees) ((pi*degrees)/180)

@interface PreView()
{
    //覆盖整个屏幕
    CALayer *mainLayer;
    //绘制红色路径
    CAShapeLayer *pathLayer;
    //显示图片层
    CAShapeLayer *fillLayer;
    //屏幕宽度
    float width;
    //屏幕高度
    float height;
    //绘制路径
    UIBezierPath *path;
    //绘制粒子效果
    CAEmitterLayer *chargeLayer;
}
-(void)drawPreView;
/*
 * 绘制主层
 */
-(void)InitMainLayer;
/*
 * 绘制路径层
 */
-(void)InitPathLayer;
/*
 * 绘制图片层
 */
-(void)InitFillLayer;
/*
 * 绘制粒子效果
 */
-(void)InitEmitterLayer;
/*
 * 绘制动画
 */
-(void)drawAnimation;

@end

@implementation PreView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    [self drawPreView];
}

-(void)InitMainLayer
{
    mainLayer = [CALayer layer];
    mainLayer.frame=CGRectMake(0, 0, width, height);
    mainLayer.backgroundColor=[UIColor blackColor].CGColor;
    [self.layer addSublayer:mainLayer];
}

-(void)InitPathLayer
{
    pathLayer=[CAShapeLayer layer];
    pathLayer.path=path.CGPath;
    pathLayer.fillColor=[UIColor clearColor].CGColor;
    pathLayer.strokeColor=[UIColor redColor].CGColor;
    pathLayer.lineWidth=3.0f;
    pathLayer.lineCap = kCALineCapRound;
    [mainLayer addSublayer:pathLayer];
}

-(void)InitFillLayer
{
    fillLayer=[CAShapeLayer layer];
    fillLayer.frame=CGRectMake(0, 0, width/4, width/4);
    fillLayer.position=CGPointMake(width/2, height/2);
    fillLayer.contents=(__bridge id)[UIImage imageNamed:@"preImage.png"].CGImage;
    fillLayer.opacity=0;
    
    fillLayer.shadowColor=[UIColor blueColor].CGColor;
    fillLayer.shadowRadius=3.0f;
    fillLayer.shadowOffset=CGSizeMake(3.0f, 3.0f);
    fillLayer.shadowOpacity=1;
    
    [mainLayer addSublayer:fillLayer];
}

-(void)InitEmitterLayer
{
    //设置发射器
    chargeLayer=[[CAEmitterLayer alloc]init];
    chargeLayer.emitterSize=CGSizeMake(self.frame.size.width-100, 20);
    chargeLayer.renderMode = kCAEmitterLayerAdditive;
    //发射单元
    //火焰
    CAEmitterCell * fire = [CAEmitterCell emitterCell];
    fire.birthRate=200;
    fire.lifetime=1.0;
    fire.lifetimeRange=0.5;
    fire.color=[[UIColor colorWithRed:0.8 green:0.4 blue:0.2 alpha:0.1]CGColor];
    fire.contents=(id)[[UIImage imageNamed:@"Sparkle"]CGImage];
    [fire setName:@"fire"];
    
    fire.velocity=160;
    fire.velocityRange=80;
    fire.emissionLongitude=M_PI+M_PI_2;
    fire.emissionRange=M_PI_2;
    fire.scale          = 0.3;
    fire.scaleRange     = 0.2;
    fire.scaleSpeed=0.3;
    fire.spin=0.2;
    
    //烟雾
    CAEmitterCell * smoke = [CAEmitterCell emitterCell];
    smoke.birthRate=100;
    smoke.lifetime=1.0;
    smoke.lifetimeRange=0.5;
    smoke.color=[[UIColor colorWithRed:1 green:1 blue:1 alpha:0.05]CGColor];
    smoke.contents=(id)[[UIImage imageNamed:@"Sparkle"]CGImage];
    [fire setName:@"smoke"];
    
    smoke.velocity=250;
    smoke.velocityRange=100;
    smoke.emissionLongitude=M_PI+M_PI_2;
    smoke.emissionRange=M_PI_2;
    smoke.scale          = 0.3;
    smoke.scaleRange     = 0.2;
    
    chargeLayer.emitterCells=[NSArray arrayWithObjects:smoke,fire,nil];
    [mainLayer addSublayer:chargeLayer];
}

-(void)drawPreView
{
    width=self.frame.size.width;
    height=self.frame.size.height;
    
    path=[UIBezierPath bezierPathWithArcCenter:CGPointMake(width/2, height/2) radius:width/4 startAngle:0 endAngle:DEGRESS_TO_RADIANS(360) clockwise:YES];
    
    [self InitMainLayer];
    
    [self InitPathLayer];
    
    [self InitFillLayer];

    [self InitEmitterLayer];
    
    [self drawAnimation];
}

-(void)drawAnimation
{
    //粒子效果动画
    CAKeyframeAnimation *animation=[CAKeyframeAnimation animation];
    animation.keyPath=@"emitterPosition";
    animation.duration=4.0;
    animation.path=path.CGPath;
    [animation setValue:fillLayer forKey:@"fillLayer"];
    animation.delegate=self;
    [chargeLayer addAnimation:animation forKey:nil];
    //线条运动动画
    CAKeyframeAnimation *strokeEndAnimation = [CAKeyframeAnimation animationWithKeyPath:@"strokeEnd"];
    strokeEndAnimation.duration = 4.0;
    strokeEndAnimation.values = @[@0.0, @1];
    strokeEndAnimation.keyTimes = @[@0.0,@1];
    [pathLayer addAnimation:strokeEndAnimation forKey:nil];
}

-(void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    CAShapeLayer *layer= [anim valueForKey:@"fillLayer"];
    CAShapeLayer *moveImgLayer= [anim valueForKey:@"moveImgLayer"];
    NSLog(@"%@",layer);
    if (layer!=nil) {
        pathLayer.strokeColor=[UIColor whiteColor].CGColor;
        //显示图片动画
        CAKeyframeAnimation *animation=[CAKeyframeAnimation animation];
        animation.keyPath=@"opacity";
        animation.duration=2.0;
        animation.values = @[@0.0, @1];
        animation.keyTimes = @[@0.0,@1];
        animation.fillMode=kCAFillModeForwards;
        animation.removedOnCompletion=NO;
        [animation setValue:layer forKey:@"moveImgLayer"];
        animation.delegate=self;
        [layer addAnimation:animation forKey:nil];
        //背景切换颜色
        CABasicAnimation *animChangeBackColor=[CABasicAnimation animation];
        animChangeBackColor.keyPath=@"backgroundColor";
        animChangeBackColor.toValue=(__bridge id)[UIColor whiteColor].CGColor;
        [self applyBasicAnimation:animChangeBackColor toLayer:mainLayer];
        return;
    }
    if (moveImgLayer!=nil) {
        //图片左右运动
        CGPoint originPos = CGPointZero;
        CGSize originSize = CGSizeZero;
        if ([moveImgLayer isKindOfClass:[CALayer class]]) {
            originPos = [(CALayer *)moveImgLayer position];
            originSize = [(CALayer *)moveImgLayer bounds].size;
        }
        CAKeyframeAnimation* moveAnimation = [CAKeyframeAnimation animation];
        moveAnimation.keyPath = @"position";
        //改变value来实现不同方向的震动
        CGFloat offsetX = 0;
        CGFloat offsetY = 0;
        offsetX = 10.0;
        moveAnimation.values = @[
                             [NSValue valueWithCGPoint:CGPointMake(originPos.x, originPos.y)],
                             [NSValue valueWithCGPoint:CGPointMake(originPos.x-offsetX, originPos.y-offsetY)],
                             [NSValue valueWithCGPoint:CGPointMake(originPos.x, originPos.y)],
                             [NSValue valueWithCGPoint:CGPointMake(originPos.x+offsetX, originPos.y+offsetY)],
                             [NSValue valueWithCGPoint:CGPointMake(originPos.x, originPos.y)]
                             ];
        moveAnimation.repeatCount = 0;
        moveAnimation.duration = 0.5;
        moveAnimation.fillMode = kCAFillModeForwards;
        [moveImgLayer addAnimation:moveAnimation forKey:nil];
    }
}
/*
 * 改变动画过程中的实体层属性
 */
-(void)applyBasicAnimation:(CABasicAnimation*)animation toLayer:(CALayer*)layer
{
    animation.fromValue=[layer.presentationLayer ?:layer valueForKey:animation.keyPath];
    
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    [layer setValue:animation.toValue forKey:animation.keyPath];
    [CATransaction commit];
    
    [layer addAnimation:animation forKey:nil];
}


@end
