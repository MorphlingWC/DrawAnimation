//
//  ViewController.m
//  DrawAnimation
//
//  Created by weichao on 10/10/16.
//  Copyright © 2016 weichao. All rights reserved.
//

#import "ViewController.h"
#import "PreView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    PreView* pView=[[PreView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    
    [self.view addSubview:pView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
