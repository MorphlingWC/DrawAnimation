//
//  PreView.h
//  PlaneGame
//
//  Created by weichao on 10/8/16.
//  Copyright © 2016 weichao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PreView : UIView

@end
